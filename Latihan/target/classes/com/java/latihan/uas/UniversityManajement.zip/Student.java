/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.java.latihan.uas;
/**
 *
 * @author ehhramaa
 */
public interface Student {
    void register();
    void displayInfo();
}
